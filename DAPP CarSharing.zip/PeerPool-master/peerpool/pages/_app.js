import '../styles/globals.css'
import '../styles/rides.css'


function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp
